<?php
header('location:get-lang/');
?>
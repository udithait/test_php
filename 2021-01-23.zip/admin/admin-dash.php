<?php
session_start();
    ob_start();
    require_once "functions/db.php";

    // Initialize the session

    

    // If session variable is not set it will redirect to login page

    if(!isset($_SESSION['empid']) || empty($_SESSION['empid'])){

      header("location: login.php");

      exit;
    }
    else
    {
        $luser = $_SESSION['empid'];
        $glus = "SELECT * FROM `admin` WHERE `empid`='$luser'";
        $getluser = mysqli_query($connection, $glus);
        while ($ftuser = mysqli_fetch_array($getluser)) 
        {
            $lfname = $ftuser['fname'];
            $llname = $ftuser['lname'];
            $lrole = $ftuser['role'];
            $lemploc = $ftuser['location'];
            $lemail = $ftuser['email'];
        }

        if ($lrole == "QA" ||$lrole == "Supervisor" ) 
        {
            header("location: index.php");
        }
    }

    $empid = $_SESSION['empid'];

    $sql_Reported = "SELECT * FROM inc_review WHERE curr_status='Reported'";
    $query_Reported = mysqli_query($connection, $sql_Reported);

    $sql_review = "SELECT * FROM inc_review WHERE curr_status='Review'";
    $query_review = mysqli_query($connection, $sql_review);

    $sql_hold = "SELECT * FROM inc_review WHERE curr_status='Hold'";
    $query_hold = mysqli_query($connection, $sql_hold);

    $sql_reject = "SELECT * FROM inc_review WHERE curr_status='Reject'";
    $query_reject = mysqli_query($connection, $sql_reject);

    $sql_completed = "SELECT * FROM inc_review WHERE curr_status='Completed'";
    $query_completed = mysqli_query($connection, $sql_completed);

    $sql_total = "SELECT * FROM inc_review";
    $query_total = mysqli_query($connection, $sql_total);

    $sql_topinc = "SELECT * FROM inc_review ORDER BY datestamp DESC LIMIT 5";
    $query_inc = mysqli_query($connection, $sql_topinc);

    $sql_done = "SELECT * FROM inc_review WHERE curr_status='Completed' ORDER BY datestamp DESC LIMIT 5";
    $query_done = mysqli_query($connection, $sql_done);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/icon.png">
    <title>Incident Managment System | Hemas Hospitals</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- toast CSS -->
    <link href="../plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
    <!-- morris CSS -->
    <link href="../plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/blue.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style type="text/css">
    .sediv{display: none;}
    .opendiv
    {
        display: block;
        opacity: 0;
    animation: fadeIn 1s ease-in both;
    }
</style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header"> <a class="navbar-toggle hidden-sm hidden-md hidden-lg " href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse"><i class="ti-menu"></i></a>
                <div class="top-left-part"><a class="logo" href="#"><b><img src="../plugins/images/icon.png" style="width: 90px; " alt="home" /></b></a></div>
                <ul class="nav navbar-top-links navbar-left hidden-xs">
                    <li><a href="javascript:void(0)" class="open-close hidden-xs waves-effect waves-light"><i class="icon-arrow-left-circle ti-menu"></i></a></li>
                    <li>
                        <form role="search" class="app-search hidden-xs">
                            <input type="text" id="se" placeholder="Search..." class="form-control"> <a href=""><i class="fa fa-search"></i></a> </form>
                    </li>
                </ul>
                <ul class="nav navbar-top-links navbar-right pull-right">
                    <!-- /.dropdown -->
                    <!-- /.dropdown -->
                </ul>
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
        </nav>
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search hidden-sm hidden-md hidden-lg">
                        <!-- input-group -->
                        <div class="input-group custom-search-form">
                            <input type="text" id="se" class="form-control" placeholder="Search..."> <span class="input-group-btn">
            <button class="btn btn-default" type="button"> <i class="fa fa-search"></i> </button>
            </span> </div>
                        <!-- /input-group -->
                    </li>
                    <li class="user-pro">
                        <a href="#" class="waves-effect"><img src="../plugins/images/user.jpg" alt="user-img" class="img-circle"> <span class="hide-menu"> Account<span class="fa arrow"></span></span>
                        </a>
                        <ul class="nav nav-second-level">
                            <li><a href="settings.php"><i class="ti-settings"></i> Account Setting</a></li>
                            <li><a href="functions/logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                        </ul>
                    </li>
                    <li class="nav-small-cap m-t-10"> Main Menu</li>
                    <li> <a href="admin-dash.php" class="waves-effect active"><i class="linea-icon linea-basic fa-fw" data-icon="v"></i> <span class="hide-menu"> Dashboard </a>
                    </li>
                    <li> <a href="#" class="waves-effect"><i data-icon="&#xe00b;" class="linea-icon linea-basic fa-fw"></i> <span class="hide-menu">Incident<span class="fa arrow"></span></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="new-incident.php">Add Incident</a></li>
                            <li><a href="inc-list.php">All Incident</a></li>
                            </li>
                        </ul>
                    </li>
                   <?php
                    if ($lrole=="Admin") 
                    {
                      echo '<li class="nav-small-cap"> Administrator </li>
                    <li> <a href="#" class="waves-effect"><i data-icon="H" class="linea-icon linea-basic fa-fw"></i> <span class="hide-menu">Access<span class="fa arrow"></span></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="users.php">Users</a></li>
                            <li><a href="locations.php">Locations</a></li>
                            <li><a href="dept.php">Departments</a></li>
                            <li><a href="units.php">Units</a></li>
                            <li><a href="types.php">Incident Types</a></li>
                            <li><a href="rating.php">Incident Ratings</a></li>
                            <li><a href="syslogs.php">System Logs</a></li>
                            <li><a href="email-config.php">Email Configuration</a></li>
                        </ul>
                    </li>';
                    }
                    ?>
                    <li><a href="functions/logout.php" class="waves-effect"><i class="icon-logout fa-fw"></i> <span class="hide-menu">Log out</span></a></li>
                </ul>
            </div>
        </div>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title"><?php echo $lfname." ".$llname;?></h4> </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12"> 
                        <ol class="breadcrumb">
                            <li><a href="#">Admin Dashboard</a></li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                    
                </div>
                <!--------------- search ------------------------>
                <div id="adse" class="sediv container">
                    <form action="inc-list.php" method="get">
                            <div class="row">
                            <div class="col-sm-12" style="margin-top: 30px;">
                                <h3>Advanced Search</h3>
                                 <input type="text" name="words" class="form-control" placeholder="Type here to search" style="width: 70%; float: left;">
                                 <button type="submit" name="se" class="form-control btn btn-info" style="width: 20%">Search</button>
                                 </div>
                            </div>
                            <div class="row" style="margin-top: 30px;">
                                <div class="col-sm-3">
                                <label>Period From</label>
                                <input type="date" class="form-control" name="fromdate">
                                </div>
                                <div class="col-sm-3">
                                <label>To</label>
                                <input type="date" class="form-control" name="todate">
                                </div>
                                <div class="col-sm-3">
                                </div>
                                <div class="col-sm-3">
                                </div>
                        </div>
                            <div class="row" style="margin-top: 30px;">
                                <div class="col-sm-3">
                                    <label>Status</label> <br>
                                    <input type="checkbox" name="status[]" value=""> All <br>
                                    <input type="checkbox" name="status[]" value="Reported"> Reported <br>
                                    <input type="checkbox" name="status[]" value="Review"> Reviewing <br>
                                    <input type="checkbox" name="status[]" value="Hold"> Hold <br>
                                    <input type="checkbox" name="status[]" value="Reject"> Reject <br>
                                    <input type="checkbox" name="status[]" value="Completed"> Completed <br>  
                                </div>
                                <div class="col-sm-3">
                                    <label>Type</label> <br>
                                    <input type="checkbox" name="inctype[]" value=""> All <br>
                                    <?php
                                                      $gettyp = "SELECT * FROM `inc_types` ";
                                                      $get_tp = mysqli_query($connection, $gettyp);
                                                      while ($lst_tp = mysqli_fetch_array($get_tp)) {
                                                        echo '
                                    <input type="checkbox" name="inctype[]" value="'.$lst_tp['typ_name'].'"> '.$lst_tp['typ_name'].' <br>
                                    ';
                                    }
                                    ?>
                                </div>
                                <div class="col-sm-3">
                                    <label>Person Involved</label> <br>
                                    <input type="checkbox" name="incperson[]" value=""> All <br>
                                    <input type="checkbox" name="incperson[]" value="In Patient"> In Patient <br>
                                    <input type="checkbox" name="incperson[]" value="Out Patient"> Out Patient <br>
                                    <input type="checkbox" name="incperson[]" value="Visitor"> Visitor <br>
                                    <input type="checkbox" name="incperson[]" value="Staff Member"> Consultant/Staff Member <br>
                                    <input type="checkbox" name="incperson[]" value="Property/Process"> Property/Process <br>
                                </div>
                                <div class="col-sm-3">
                                    <label>Rating</label> <br>
                                    <input type="checkbox" name="routing[]" value=""> All <br>
                                    <?php
                                    $getrat = "SELECT * FROM `inc_rating`";
                                    $get_rat = mysqli_query($connection, $getrat);
                                    while ($lst_rat = mysqli_fetch_array($get_rat)) 
                                    {
                                        echo '<input type="checkbox" name="routing[]" value="'.$lst_rat["rat_name"].'"> '.$lst_rat["rat_name"].' <br>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="row" style="margin-top: 30px; margin-bottom: 60px;">
                                <div class="col-sm-3">
                                    <label>User</label>
                                                <select class="form-control" name="suser">
                                                      <option value="">-- Select User--</option>
                                                      <?php
                                                      $getuser = "SELECT * FROM `admin` ";
                                                      $get_user = mysqli_query($connection, $getuser);
                                                      while ($lst_user = mysqli_fetch_array($get_user)) {
                                                      echo '<option value="'.$lst_user["empid"].'">'.$lst_user["fname"]." ".$lst_user["lname"].'('.$lst_user["empid"].')</option>';
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Department</label>
                                                <select class="form-control" name="sdepart">
                                                      <option value="">-- Select Department--</option>
                                                      <?php
                                                      $getdpt = "SELECT * FROM `inc_depart` ";
                                                      $get_dpt = mysqli_query($connection, $getdpt);
                                                      while ($lst_dept = mysqli_fetch_array($get_dpt)) {
                                                      echo '<option value="'.$lst_dept["dpt_name"].'">'.$lst_dept["dpt_name"].'</option>';
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Location Occurred</label>
                                                <select class="form-control" name="slocation">
                                                      <option value="">-- Select Location--</option>
                                                      <?php
                                                      if ($lrole =="QA")
                                                      {
                                                            echo '<option value="'.$lemploc.'">'.$lemploc.'</option>';
                                                      }
                                                      else
                                                      {
                                                        $getoclc = "SELECT * FROM `inc_locations`";
                                                        $get_oclc = mysqli_query($connection, $getoclc);
                                                        while ($lst_oclc = mysqli_fetch_array($get_oclc)) {
                                                            echo '<option value="'.$lst_oclc["loc_name"].'">'.$lst_oclc["loc_name"].'</option>';
                                                            }
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Location Reported</label>
                                    <select class="form-control" name="srptlocation">
                                                      <option value="">-- Select Location--</option>
                                                      <?php
                                                      $getrplc = "SELECT * FROM `inc_locations`";
                                                      $get_rplc = mysqli_query($connection, $getrplc);
                                                      while ($lst_rplc = mysqli_fetch_array($get_rplc)) {
                                                      echo '<option value="'.$lst_rplc["loc_name"].'">'.$lst_rplc["loc_name"].'</option>';
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                            </div>
                            </form>
                </div>
                <!-----------------end search ---------------->
                <?php 
                if (isset($_GET['set'])) {
                    echo'<div class="alert alert-success" >
                     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                   <strong>DONE!! </strong><p> Your password has been successfully updated.</p>
                     </div>';
                        }
                ?>
                <!-- /.row -->
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12">
                        <div class="white-box">
                            <div class="row row-in">
                                <div class="col-lg-2 col-sm-4 row-in-br">
                                    <div class="col-in row">
                                        <div class="col-md-6 col-sm-6 col-xs-6"> <i class="fa fa-list" aria-hidden="true"></i>
                                            <h5 class="text-muted vb">Reported</h5> </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                            <h3 class="counter text-right m-t-15 text-info"><?php echo mysqli_num_rows($query_Reported);?></h3> </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div style="text-align: right">
                                                <a href="inc-list.php?dtype=Reported" class="btn btn-info">View All<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-2 col-sm-4 row-in-br  b-r-none">
                                    <div class="col-in row">
                                        <div class="col-md-6 col-sm-6 col-xs-6"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                            <h5 class="text-muted vb">Reviewing</h5> </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                            <h3 class="counter text-right m-t-15 text-megna"><?php echo mysqli_num_rows($query_review);?></h3> </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div style="text-align: right">
                                                <a href="inc-list.php?dtype=Review" class="btn btn-default" style="background:#01c0c8!important; color: white">View All<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-2 col-sm-4 row-in-br">
                                    <div class="col-in row">
                                        <div class="col-md-6 col-sm-6 col-xs-6"> <i class="fa fa-exclamation" aria-hidden="true"></i>
                                            <h5 class="text-muted vb">Hold</h5> </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                            <h3 class="counter text-right m-t-15 text-warning"><?php echo mysqli_num_rows($query_hold);?></h3> </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div style="text-align: right">
                                                <a href="inc-list.php?dtype=Hold" class="btn btn-warning">View All<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-2 col-sm-4  row-in-br">
                                    <div class="col-in row">
                                        <div class="col-md-6 col-sm-6 col-xs-6"> <i class="fa fa-times" aria-hidden="true"></i>
                                            <h5 class="text-muted vb">Reject</h5> </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                            <h3 class="counter text-right m-t-15 text-danger"><?php echo mysqli_num_rows($query_reject);?></h3> </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div style="text-align: right">
                                                <a href="inc-list.php?dtype=Reject" class="btn btn-danger">View All<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-2 col-sm-4  row-in-br">
                                    <div class="col-in row">
                                        <div class="col-md-6 col-sm-6 col-xs-6"> <i class="fa fa-check-square-o" aria-hidden="true"></i>
                                            <h5 class="text-muted vb">Completed</h5> </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                            <h3 class="counter text-right m-t-15 text-success"><?php echo mysqli_num_rows($query_completed);?></h3> </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div style="text-align: right">
                                                <a href="inc-list.php?dtype=Completed" class="btn btn-success">View All<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-2 col-sm-4  b-0">
                                    <div class="col-in row">
                                        <div class="col-md-6 col-sm-6 col-xs-6"> <i class="fa fa-archive" aria-hidden="true"></i>
                                            <h5 class="text-muted vb">Total</h5> </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6">
                                            <h3 class="counter text-right m-t-15 text-primary"><?php echo mysqli_num_rows($query_total);?></h3> </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div style="text-align: right">
                                                <a href="inc-list.php" class="btn btn-primary">View All<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--row -->
                <div class="row">
                    <div class="col-md-12 col-lg-5 col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title">Recent Completed Incidents</h3>
                            <div class="comment-center">
                                <div class="comment-body">
                                    <div class="mail-contnet">
                                        <table class="table table-responsive">
                                      <?php
                                             if (mysqli_num_rows($query_done)==0) {
                                                 echo "<i style='color:brown;'>There are no Completed Incidents </i> ";
                                                    }
                                                    else{

                                    $counter = 0;
                                    $max = 5;

                                    while ($row2 = mysqli_fetch_array($query_done)) {
                                    $lbcl = "label label-default";
                                                    
                                        
                                    echo '                
                                        <tr>
                                        <td>'.$row2["fname"]." ".$row2["lname"].'</td>
                                            <td class="max-texts"><span class="'.$lbcl.'">'.$row2["inc_type"].'</span></td>
                                            <td>'.$row2["location"].'</td>
                                         </tr>   
                                    ';
                                   } }
                                    ?>
                                    </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-7 col-sm-12">
                        <div class="white-box">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <h2>Recent Incidents</h2> 
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-responsive">
                                <?php
                                             if (mysqli_num_rows($query_inc)==0) {
                                                 echo "<i style='color:brown;'>No Incidents Yet.. </i> ";
                                                    }
                                                    else
                                                        
                                                    {
                                                        echo '
                                                             <thead>
                                                            <tr>
                                                                <th>Name/Property</th>
                                                                <th> Person Involved</th>
                                                                <th> Location</th>
                                                                <th> Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        ';
                                                    }
                                                        $counter = 0;
                                                        $max = 5;

                                                while (($row = mysqli_fetch_array($query_inc)) and ($counter < $max) )
                                                {
                                                    $lbcl = "label label-default";
                                                    if ($row["inc_person"]=="In Patient") 
                                                    {
                                                       $lbcl = "label label-success";
                                                    }
                                                    if ($row["inc_person"]=="Out Patient") 
                                                    {
                                                       $lbcl = "label label-primary";
                                                    }
                                                    if ($row["inc_person"]=="Property/Process") 
                                                    {
                                                       $lbcl = "label label-info";
                                                    }
                                                    if ($row["inc_person"]=="Visitor") 
                                                    {
                                                       $lbcl = "label label-warning";
                                                    }
                                                    if ($row["inc_person"]=="Staff Member") 
                                                    {
                                                       $lbcl = "label label-danger";
                                                    }
                                              echo '
                                        <tr>
                                            <td>'.$row["fname"]." ".$row["lname"].'</td>
                                            <td class="max-texts"><span class="'.$lbcl.'">'.$row["inc_person"].'</span></td>
                                            <td>'.$row["location"].'</td>
                                            <td><a href="inc-details.php?id='.$row["review_id"].'" class="btn btn-success" style="color:white">View</a></td>
                                        </tr>
                                    ';
                                    $counter++;
                                        }
                                    ?>
                                    </tbody>

                                </table> 
                                       <a href="inc-list.php" class="btn btn-info waves-effect waves-light">View All Incidents</a>
                                     </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"> <?php echo date('Y'); ?> &copy; Hemas Hospitals. All Rights Reserved. </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/tether.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Counter js -->
    <script src="../plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="../plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <!--Morris JavaScript -->
    <script src="../plugins/bower_components/raphael/raphael-min.js"></script>
    <script src="../plugins/bower_components/morrisjs/morris.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <script src="js/dashboard1.js"></script>
    <!-- Sparkline chart JavaScript -->
    <script src="../plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="../plugins/bower_components/jquery-sparkline/jquery.charts-sparkline.js"></script>
    <script src="../plugins/bower_components/toast-master/js/jquery.toast.js"></script>
    <script type="text/javascript">
    /*$(document).ready(function() {
        $.toast({
            heading: 'Welcome to Company admin',
            text: 'view, edit and upload new posts to keep your users engaged.',
            position: 'top-right',
            loaderBg: '#ff6849',
            icon: 'info',
            hideAfter: 3700,
            stack: 6
        })
    });*/
    </script>
    <!--Style Switcher -->
    <script src="../plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
    <script type="text/javascript">
$(document).ready(function(){
    $('#se').click(function() {
    $('#adse').toggleClass('opendiv');
    });
    });
</script>
</body>
</html>
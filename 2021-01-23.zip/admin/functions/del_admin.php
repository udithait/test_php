<?php 
session_start();
$emppid = $_SESSION['empid'];
 
require_once "db.php";

if (isset($_POST["id"])) {

	$id = $_POST["id"];

	$sql = "DELETE FROM admin WHERE id=?";

  $getuser = "SELECT * FROM `admin` WHERE id='$id'";
  $delus = mysqli_query($connection, $getuser);
  while ($row = mysqli_fetch_array($delus)) 
  {
    $empid = $row["empid"];
  }

$stmt = $db->prepare($sql);


    try {
      $stmt->execute([$id]);

      $delsq = "DELETE FROM `inc_email` WHERE `empid`='$empid'";
      mysqli_query($connection, $delsq);

      $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('User Removed : $empid','$emppid')" ;
      mysqli_query($connection, $logsql);

      header('Location:../users.php?deleted');

      }

     catch (Exception $e) {
        $e->getMessage();
        echo "Error";
    }

}
else {
	header('Location:../users.php?del_error');
}
?>
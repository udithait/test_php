<?php 
session_start();
$emppid = $_SESSION['empid'];
 
require_once "db.php";

if (isset($_POST["id"])) {

	$id = $_POST["id"];

	$sql = "DELETE FROM `inc_depart` WHERE `dpt_id`=?";

$getdp = "SELECT * FROM `inc_depart`  WHERE dpt_id='$id'";
  $deldp = mysqli_query($connection, $getdp);
  while ($row = mysqli_fetch_array($deldp)) 
  {
    $dptname = $row["dpt_name"];
  }
$stmt = $db->prepare($sql);


    try {
      $stmt->execute([$id]);

      $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('Department Removed : $dptname','$emppid')" ;
      mysqli_query($connection, $logsql);

      header('Location:../dept.php?deleted');

      }

     catch (Exception $e) {
        $e->getMessage();
        echo "Error";
    }

}
else {
	header('Location:../dept.php?del_error');
}
?>
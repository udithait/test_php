<?php
session_start();
$emppid = $_SESSION['empid'];

 require('db.php');
  if (isset($_POST['submit'])) 
  {
      $tpname = $_POST['tpname'];
      
      //-- Insert Data Into DB --//
      $sql = "INSERT INTO `inc_types`(`typ_name`, `status`) VALUES ('$tpname','1')";
      //-- Insert Data Into DB --//

     

      try {
       
        mysqli_query($connection, $sql); 

        $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('Incident Type Created : $tpname','$emppid')" ;
      mysqli_query($connection, $logsql);

        header('Location:../types.php?success');

      }

       catch (Exception $e) {
          $e->getMessage();
          echo "Error";
      }
    }















?>

<?php 
session_start();
$emppid = $_SESSION['empid'];
 
require_once "db.php";

if (isset($_POST["id"])) {

	$id = $_POST["id"];

	$sql = "DELETE FROM `inc_locations` WHERE `loc_id`=?";

$getloc = "SELECT * FROM `inc_locations` WHERE loc_id='$id'";
  $delloc = mysqli_query($connection, $getloc);
  while ($row = mysqli_fetch_array($delloc)) 
  {
    $locname = $row["loc_name"];
  }

$stmt = $db->prepare($sql);


    try {
      $stmt->execute([$id]);

      $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('Location Removed : $locname','$emppid')" ;
      mysqli_query($connection, $logsql);

      header('Location:../locations.php?deleted');

      }

     catch (Exception $e) {
        $e->getMessage();
        echo "Error";
    }

}
else {
	header('Location:../locations.php?del_error');
}
?>
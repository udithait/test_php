<?php
session_start();
$emppid = $_SESSION['empid'];

 require('db.php');
  if (isset($_POST['submit'])) 
  {
      $rtname = $_POST['rtname'];
      
      //-- Insert Data Into DB --//
      $sql = "INSERT INTO `inc_rating`(`rat_name`, `status`) VALUES ('$rtname','1')";
      //-- Insert Data Into DB --//

     

      try {
       
        mysqli_query($connection, $sql); 

        $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('New Rating Created : $rtname','$emppid')" ;
      mysqli_query($connection, $logsql);

        header('Location:../rating.php?success');

      }

       catch (Exception $e) {
          $e->getMessage();
          echo "Error";
      }
    }















?>

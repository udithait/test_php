<?php 
session_start();
$emppid = $_SESSION['empid'];
 
require_once "db.php";

if (isset($_POST["id"])) {

	$id = $_POST["id"];

	$sql = "DELETE FROM `inc_rating` WHERE `rat_id`=?";

$getrt = "SELECT * FROM `inc_rating`  WHERE rat_id='$id'";
  $delrt = mysqli_query($connection, $getrt);
  while ($row = mysqli_fetch_array($delrt)) 
  {
    $ratname = $row["rat_name"];
  }
$stmt = $db->prepare($sql);


    try {
      $stmt->execute([$id]);

      $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('Rating Removed : $ratname','$emppid')" ;
      mysqli_query($connection, $logsql);

      header('Location:../rating.php?deleted');

      }

     catch (Exception $e) {
        $e->getMessage();
        echo "Error";
    }

}
else {
	header('Location:../rating.php?del_error');
}
?>
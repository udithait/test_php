<?php
session_start();
$emppid = $_SESSION['empid'];

 require('db.php');
  if (isset($_POST['submit'])) 
  {
      $dpname = $_POST['dpname'];
      
      //-- Insert Data Into DB --//
      $sql = "INSERT INTO `inc_depart`(`dpt_name`, `status`) VALUES ('$dpname','1')";
      //-- Insert Data Into DB --//

     

      try {
       
        mysqli_query($connection, $sql); 

        $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('Department Created : $dpname','$emppid')" ;
      mysqli_query($connection, $logsql);

        header('Location:../dept.php?success');

      }

       catch (Exception $e) {
          $e->getMessage();
          echo "Error";
      }
    }















?>

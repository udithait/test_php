<?php 
session_start();
$emppid = $_SESSION['empid'];
// Database Connectuion
require_once "db.php";

// UPDATE PASSWORD

	
	if (isset($_POST['submit'])) {

		$password = password_hash($_POST['password'],PASSWORD_BCRYPT,array('cost'=>12));

		$empid = $_POST["empid"];
    $luser = $_SESSION['empid'];
    $glus = "SELECT * FROM `admin` WHERE `empid`='$luser'";
    $getluser = mysqli_query($connection, $glus);
      while ($ftuser = mysqli_fetch_array($getluser)) 
      {
          $lfname = $ftuser['fname'];
          $llname = $ftuser['lname'];
          $lrole = $ftuser['role'];
      }

        

			$sql = "UPDATE admin SET password = '$password' WHERE empid = '$empid' ";

	$stmt = $db->prepare($sql);


    try {
      $stmt->execute([$password]);

      $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('User Password Changed : $emppid','$emppid')" ;
      mysqli_query($connection, $logsql);
      
      if ($lrole == "QA" ||$lrole == "Supervisor" ) 
        {
            header('location:../index.php?set');
        }
      if ($lrole == "Admin") 
        {
            header('Location:../admin-dash.php?set');
        }

      }

     catch (Exception $e) {
        $e->getMessage();
        echo "Error";
    }

}


// UPDATE PASSWORD


?>
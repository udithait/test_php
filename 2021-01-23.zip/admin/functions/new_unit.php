<?php
session_start();
$emppid = $_SESSION['empid'];

 require('db.php');
  if (isset($_POST['submit'])) 
  {
      $utname = $_POST['utname'];
      $dpid = $_POST['dpt'];
      //$dpname=$_POST['dpname'];

      $rd = "SELECT * FROM `inc_depart` WHERE `dpt_id`='$dpid'";
      $getdp = mysqli_query($connection, $rd);
      while ($rdname = mysqli_fetch_array($getdp)) 
      {
       $dpname = $rdname["dpt_name"];
      }

      
      $displytxt = $utname."/".$dpname;
      //-- Insert Data Into DB --//
      $sql = "INSERT INTO `inc_deplocation`(`location`, `dpt_id`, `department`, `displytxt`, `status`) VALUES ('$utname','$dpid','$dpname','$displytxt','1')";
      //-- Insert Data Into DB --//

     

      try {
       
        mysqli_query($connection, $sql);

        $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('Department Unit Created : $utname','$emppid')" ;
      mysqli_query($connection, $logsql);

        header('Location:../units.php?success');

      }

       catch (Exception $e) {
          $e->getMessage();
          echo "Error";
      }
    }















?>

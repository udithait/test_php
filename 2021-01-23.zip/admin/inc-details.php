<?php
session_start();
    ob_start();
    require_once "functions/db.php";

    // Initialize the session
$logfname="";
    

    // If session variable is not set it will redirect to login page

    if(!isset($_SESSION['empid']) || empty($_SESSION['empid'])){

      header("location: login.php");

      exit;
    }
    else
    {
        $luser = $_SESSION['empid'];
        $glus = "SELECT * FROM `admin` WHERE `empid`='$luser'";
        $getluser = mysqli_query($connection, $glus);
        while ($ftuser = mysqli_fetch_array($getluser)) 
        {
            $lfname = $ftuser['fname'];
            $llname = $ftuser['lname'];
            $lrole = $ftuser['role'];
            $lemploc = $ftuser['location'];
            $lemail = $ftuser['email'];
        }
    }

    $empid = $_SESSION['empid'];

        if (isset($_GET['id'])) {
        $reviewid = $_GET['id'];
      }
      else {
        header('Location:inc-list.php');
      }
      $inc_id="";
      $inc_summery = "";
      $inc_rating = "";
      $inc_remark = "";
      $rootcase = "";


     $sql="SELECT * FROM inc_review WHERE review_id='$reviewid'";

     $query = mysqli_query($connection, $sql);
     while ($row = mysqli_fetch_assoc($query)) {
            $review_id = $row["review_id"];
            $inc_id = $row["inc_id"];
            $paitient_emp_id = $row["paitient_emp_id"];
            $fname = $row["fname"];
            $lname = $row["lname"];
            $inc_person = $row["inc_person"];
            $inc_type = $row["inc_type"];
            $inc_details = $row["inc_details"];
            $nodate = $row["nodate"];
            $date = $row["date"];
            $department = $row["department"];
            $location = $row["location"];
            $rpt_location = $row["rpt_location"];
            $inc_location = $row["inc_location"];
            $email = $row["email"];
            $curr_status = $row["curr_status"];
            $datestamp = $row["datestamp"];
            $user = $row["user"];
            $lbcl = "label label-default";
            $inc_summery = $row["inc_summery"];
            $inc_rating = $row["inc_rating"];
            $inc_remark = $row["remark"];
            $rootcase = $row["root_cause"];



                                            if ($row["inc_person"]=="In Patient") 
                                            {
                                                $lbcl = "label label-success";
                                                $sql2 = "SELECT * FROM inc_inpatient WHERE inc_inpat_id=$inc_id";
                                                $query2 = mysqli_query($connection, $sql2);
                                                while ($row2 = mysqli_fetch_assoc($query2)) 
                                                {
                                                    $age = $row2["age"];
                                                    $gender = $row2["gender"];
                                                    $reason = $row2["reason"];
                                                    $admit_date = $row2["admit_date"];
                                                    $uemail = $row2["email"];
                                                    $subscribe = $row2["subscribe"];
                                                }
                                            }
                                            if ($row["inc_person"]=="Out Patient") 
                                            {
                                                $lbcl = "label label-primary";
                                                $sql3 = "SELECT * FROM inc_outpatient WHERE inc_outpat_id=$inc_id";
                                                $query3 = mysqli_query($connection, $sql3);
                                                while ($row3 = mysqli_fetch_assoc($query3)) 
                                                {
                                                    $age = $row3["age"];
                                                    $gender = $row3["gender"];
                                                    $reason = $row3["reason"];
                                                    $admit_date = $row3["admit_date"];
                                                    $uemail = $row3["email"];
                                                    $subscribe = $row3["subscribe"];
                                                }
                                            }
                                            if ($row["inc_person"]=="Property/Process") 
                                            {
                                                $lbcl = "label label-info";
                                                $sql4 = "SELECT * FROM inc_property WHERE inc_prop_id=$inc_id";
                                                $query4 = mysqli_query($connection, $sql4);
                                                while ($row4 = mysqli_fetch_assoc($query4)) 
                                                {
                                                    $uemail = $row4["email"];
                                                    $subscribe = $row4["subscribe"];
                                                }
                                            }
                                            if ($row["inc_person"]=="Visitor") 
                                            {
                                                $lbcl = "label label-warning";
                                                $sql5 = "SELECT * FROM inc_visitor WHERE inc_visit_id=$inc_id";
                                                $query5 = mysqli_query($connection, $sql5);
                                                while ($row5 = mysqli_fetch_assoc($query5)) 
                                                {
                                                    $gender = $row5["gender"];
                                                    $reason = $row5["reason"];
                                                    $admit_date = $row5["admit_date"];
                                                    $uemail = $row5["email"];
                                                    $subscribe = $row5["subscribe"];
                                                }
                                            }
                                            if ($row["inc_person"]=="Staff Member") 
                                            {
                                                $lbcl = "label label-danger";
                                                $sql6 = "SELECT * FROM inc_staff WHERE inc_staff_id=$inc_id";
                                                $query6 = mysqli_query($connection, $sql6);
                                                while ($row6 = mysqli_fetch_assoc($query6)) 
                                                {
                                                    $designation = $row6["designation"];
                                                    $uemail = $row6["email"];
                                                    $subscribe = $row6["subscribe"];
                                                }
                                            }

                                

                               }




      if (isset($_POST['sub'])) 
      {
          $gisrating = $_POST['israting'];
          $gremark = $_POST['remark'];
          $groot = $_POST['root'];
          $ginc_type = $_POST['ginc_type'];
          $gsummery = $_POST['summery'];
          $gstst = $_POST['stst'];
          $gstremark = $_POST['stremark'];
          $gslocation = $_POST['gslocation'];
          
          if ($subscribe =="1" && $uemail !="") 
            {
                $to = $uemail;
                $subject = "Incident Update";
                $txt = "Your incident's status has been change to : ".$gstst;
                $headers = "From: webmaster@bytefactorylk.com" . "\r\n";

                mail($to,$subject,$txt,$headers);
            }
          
          $sql1= "UPDATE `inc_review` SET `inc_type`='$ginc_type', `curr_status`='$gstst',`inc_summery`='$gsummery',`inc_rating`='$gisrating',`remark`='$gremark',`root_cause`='$groot', `inc_location`='$gslocation' WHERE `review_id`='$review_id'";

          

          try {
            mysqli_query($connection, $sql1);
            

            

            if ($inc_location != $gslocation) 
            {

                $sql2 ="INSERT INTO `inc_logs`(`inc_id`, `remark`, `curr_status`, `user`) VALUES ('$inc_id','- Location Changed to : $gslocation - $gstremark','$gstst','$empid')";
                mysqli_query($connection, $sql2);

                $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('Incident Updated or Status Changed. - Location Changed to : $gslocation - Incident ID : $review_id ','$empid')" ;
                mysqli_query($connection, $logsql);

                header('Location:inc-list.php');
            }
            else
            {
                $sql2 ="INSERT INTO `inc_logs`(`inc_id`, `remark`, `curr_status`, `user`) VALUES ('$inc_id','$gstremark','$gstst','$empid')";
                mysqli_query($connection, $sql2);

                $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('Incident Updated or Status Changed. Incident ID : $review_id ','$empid')" ;
                mysqli_query($connection, $logsql);

                header('Location:?id='.$reviewid);
            }

      }

     catch (Exception $e) {
        $e->getMessage();
        echo "Error";
    }
      }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/icon.png">
    <title>Details | Incident Management System</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- morris CSS -->
    <link href="../plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/blue.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style type="text/css">
    .sediv{display: none;}
    .opendiv
    {
        display: block;
        opacity: 0;
    animation: fadeIn 1s ease-in both;
    }
</style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header"> <a class="navbar-toggle hidden-sm hidden-md hidden-lg " href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse"><i class="ti-menu"></i></a>
                <div class="top-left-part"><a class="logo" href="#"><b><img src="../plugins/images/icon.png" style="width: 90px; " alt="home" /></b></a></div>
                <ul class="nav navbar-top-links navbar-left hidden-xs">
                    <li><a href="javascript:void(0)" class="open-close hidden-xs waves-effect waves-light"><i class="icon-arrow-left-circle ti-menu"></i></a></li>
                    <li>
                        <form role="search" class="app-search hidden-xs">
                            <input type="text" placeholder="Search..." id="se" class="form-control"> <a href=""><i class="fa fa-search"></i></a> </form>
                    </li>
                </ul>
                <ul class="nav navbar-top-links navbar-right pull-right">
                    <!-- /.dropdown -->
                    <!-- /.dropdown -->
                </ul>
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
        </nav>
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search hidden-sm hidden-md hidden-lg">
                        <!-- input-group -->
                        <div class="input-group custom-search-form">
                            <input type="text" id="se" class="form-control" placeholder="Search..."> <span class="input-group-btn">
            <button class="btn btn-default" type="button"> <i class="fa fa-search"></i> </button>
            </span> </div>
                        <!-- /input-group -->
                    </li>
                    <li class="user-pro">
                        <a href="#" class="waves-effect"><img src="../plugins/images/user.jpg" alt="user-img" class="img-circle"> <span class="hide-menu"> Account<span class="fa arrow"></span></span>
                        </a>
                        <ul class="nav nav-second-level">
                            <li><a href="settings.php"><i class="ti-settings"></i> Account Setting</a></li>
                            <li><a href="functions/logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                        </ul>
                    </li>
                    <li class="nav-small-cap m-t-10"> Main Menu</li>
                    <?php
                    if ($lrole=="QA" || $lrole =="Supervisor") 
                    {
                    echo '<li> <a href="index.php" class="waves-effect"><i class="linea-icon linea-basic fa-fw" data-icon="v"></i> <span class="hide-menu"> Dashboard </a>
                    </li>';
                    }
                    if ($lrole=="Admin") 
                    {
                        echo'<li> <a href="admin-dash.php" class="waves-effect"><i class="linea-icon linea-basic fa-fw" data-icon="v"></i> <span class="hide-menu"> Dashboard </a>
                    </li>';
                    }
                    ?>
                    <li> <a href="#" class="waves-effect"><i data-icon="&#xe00b;" class="linea-icon linea-basic fa-fw"></i> <span class="hide-menu">Incident<span class="fa arrow"></span></span></a>
                        <ul class="nav nav-second-level">
                            <?php
                            if ($lrole =="Admin" || $lrole=="QA") 
                            {
                                echo '<li><a href="new-incident.php">New Incident</a></li>';
                            }
                            ?>
                            <li><a href="inc-list.php">All Incident</a></li>
                        </ul>
                    </li>
                   <?php
                    if ($lrole=="Admin") 
                    {
                      echo '<li class="nav-small-cap"> Administrator </li>
                    <li> <a href="#" class="waves-effect"><i data-icon="H" class="linea-icon linea-basic fa-fw"></i> <span class="hide-menu">Access<span class="fa arrow"></span></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="users.php">Users</a></li>
                            <li><a href="locations.php">Locations</a></li>
                            <li><a href="dept.php">Departments</a></li>
                            <li><a href="units.php">Units</a></li>
                            <li><a href="types.php">Incident Types</a></li>
                            <li><a href="rating.php">Incident Ratings</a></li>
                            <li><a href="syslogs.php">System Logs</a></li>
                            <li><a href="email-config.php">Email Configuration</a></li>
                        </ul>
                    </li>';
                    }
                    ?>
                    <li><a href="functions/logout.php" class="waves-effect"><i class="icon-logout fa-fw"></i> <span class="hide-menu">Log out</span></a></li>
                </ul>
            </div>
        </div>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <a href="inc-list.php" class="waves-effect "><i data-icon="&#xe020;" class="linea-icon linea-basic fa-fw"></i> <span class="hide-menu">Go Back</span></a>
                        <h4 class="page-title"><?php echo $lfname." ".$llname;?></h4> </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12"> 
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">Incident Detail</li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!--------------- search ------------------------>
                <div id="adse" class="sediv container">
                    <form action="inc-list.php" method="get">
                            <div class="row">
                            <div class="col-sm-12" style="margin-top: 30px;">
                                <h3>Advanced Search</h3>
                                 <input type="text" name="words" class="form-control" placeholder="Type here to search" style="width: 70%; float: left;">
                                 <button type="submit" name="se" class="form-control btn btn-info" style="width: 20%">Search</button>
                                 </div>
                            </div>
                            <div class="row" style="margin-top: 30px;">
                                <div class="col-sm-3">
                                <label>Period From</label>
                                <input type="date" class="form-control" name="fromdate">
                                </div>
                                <div class="col-sm-3">
                                <label>To</label>
                                <input type="date" class="form-control" name="todate">
                                </div>
                                <div class="col-sm-3">
                                </div>
                                <div class="col-sm-3">
                                </div>
                        </div>
                            <div class="row" style="margin-top: 30px;">
                                <div class="col-sm-3">
                                    <label>Status</label> <br>
                                    <input type="checkbox" name="status[]" value=""> All <br>
                                    <input type="checkbox" name="status[]" value="Reported"> Reported <br>
                                    <input type="checkbox" name="status[]" value="Review"> Reviewing <br>
                                    <input type="checkbox" name="status[]" value="Hold"> Hold <br>
                                    <input type="checkbox" name="status[]" value="Reject"> Reject <br>
                                    <input type="checkbox" name="status[]" value="Completed"> Completed <br>  
                                </div>
                                <div class="col-sm-3">
                                    <label>Type</label> <br>
                                    <input type="checkbox" name="inctype[]" value=""> All <br>
                                    <?php
                                                      $gettyp = "SELECT * FROM `inc_types` ";
                                                      $get_tp = mysqli_query($connection, $gettyp);
                                                      while ($lst_tp = mysqli_fetch_array($get_tp)) {
                                                        echo '
                                    <input type="checkbox" name="inctype[]" value="'.$lst_tp['typ_name'].'"> '.$lst_tp['typ_name'].' <br>
                                    ';
                                    }
                                    ?>
                                </div>
                                <div class="col-sm-3">
                                    <label>Person Involved</label> <br>
                                    <input type="checkbox" name="incperson[]" value=""> All <br>
                                    <input type="checkbox" name="incperson[]" value="In Patient"> In Patient <br>
                                    <input type="checkbox" name="incperson[]" value="Out Patient"> Out Patient <br>
                                    <input type="checkbox" name="incperson[]" value="Visitor"> Visitor <br>
                                    <input type="checkbox" name="incperson[]" value="Staff Member"> Consultant/Staff Member <br>
                                    <input type="checkbox" name="incperson[]" value="Property/Process"> Property/Process <br>
                                </div>
                                <div class="col-sm-3">
                                    <label>Rating</label> <br>
                                    <input type="checkbox" name="routing[]" value=""> All <br>
                                    <?php
                                    $getrat = "SELECT * FROM `inc_rating`";
                                    $get_rat = mysqli_query($connection, $getrat);
                                    while ($lst_rat = mysqli_fetch_array($get_rat)) 
                                    {
                                        echo '<input type="checkbox" name="routing[]" value="'.$lst_rat["rat_name"].'"> '.$lst_rat["rat_name"].' <br>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="row" style="margin-top: 30px; margin-bottom: 60px;">
                                <div class="col-sm-3">
                                    <label>User</label>
                                                <select class="form-control" name="suser">
                                                      <option value="">-- Select User--</option>
                                                      <?php
                                                      $getuser = "SELECT * FROM `admin` ";
                                                      $get_user = mysqli_query($connection, $getuser);
                                                      while ($lst_user = mysqli_fetch_array($get_user)) {
                                                      echo '<option value="'.$lst_user["empid"].'">'.$lst_user["fname"]." ".$lst_user["lname"].'('.$lst_user["empid"].')</option>';
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Department</label>
                                                <select class="form-control" name="sdepart">
                                                      <option value="">-- Select Department--</option>
                                                      <?php
                                                      $getdpt = "SELECT * FROM `inc_depart` ";
                                                      $get_dpt = mysqli_query($connection, $getdpt);
                                                      while ($lst_dept = mysqli_fetch_array($get_dpt)) {
                                                      echo '<option value="'.$lst_dept["dpt_name"].'">'.$lst_dept["dpt_name"].'</option>';
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Location Occurred</label>
                                                <select class="form-control" name="slocation">
                                                      <option value="">-- Select Location--</option>
                                                      <?php
                                                      if ($lrole =="QA")
                                                      {
                                                            echo '<option value="'.$lemploc.'">'.$lemploc.'</option>';
                                                      }
                                                      else
                                                      {
                                                        $getoclc = "SELECT * FROM `inc_locations`";
                                                        $get_oclc = mysqli_query($connection, $getoclc);
                                                        while ($lst_oclc = mysqli_fetch_array($get_oclc)) {
                                                            echo '<option value="'.$lst_oclc["loc_name"].'">'.$lst_oclc["loc_name"].'</option>';
                                                            }
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Location Reported</label>
                                    <select class="form-control" name="srptlocation">
                                                      <option value="">-- Select Location--</option>
                                                      <?php
                                                      $getrplc = "SELECT * FROM `inc_locations`";
                                                      $get_rplc = mysqli_query($connection, $getrplc);
                                                      while ($lst_rplc = mysqli_fetch_array($get_rplc)) {
                                                      echo '<option value="'.$lst_rplc["loc_name"].'">'.$lst_rplc["loc_name"].'</option>';
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                            </div>
                            </form>
                </div>
                <!-----------------end search ---------------->
                <!-- row -->
                <div class="row">
                    <!-- Left sidebar -->
                    <div class="col-md-12">
                        <div class="white-box">
                            <div class="row">
                                <div class="col-lg-12 col-md-9 col-sm-8 col-xs-12 mail_listing">
                                    
                                        <table id="example23" class="table" width="100%">
                                            <tr>
                                                <th colspan="4"><h3 align="center">Incident Report</h3></th>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <h3> <?php echo '<span class="'.$lbcl.'">'.$inc_person.'</span>'; ?> 
                                                        <?php 
                                                        /////////////////////////////////////
                                                    if ($curr_status=="Reported") 
                                                    {
                                                       $clb ="btn-info";
                                                       $stcl=""; 
                                                    }
                                                    if ($curr_status=="Review") 
                                                    {
                                                       $clb ="btn-default";
                                                       $stcl ='style="background:#01c0c8!important; color: white"';
                                                    }
                                                    if ($curr_status=="Hold") 
                                                    {
                                                       $clb ="btn-warning";
                                                       $stcl=""; 
                                                    }
                                                    if ($curr_status=="Reject") 
                                                    {
                                                       $clb ="btn-danger"; 
                                                       $stcl="";
                                                    }
                                                    if ($curr_status=="Completed") 
                                                    {
                                                       $clb ="btn-success";
                                                       $stcl ='style="background:#00c292!important; color: white"'; 
                                                    }

            ////////////////////////////////////
                                                            echo '<span class="label '.$clb.'" '.$stcl.'>'.$curr_status.'<span>';
                                                        ?>
                                                </h3>
                                                </td>
                                                
                                                <td>
                                                    <i style="font-size:15px; color:orange;">Recorded Date : <?php echo $datestamp; ?> </i> <br>
                                                    <i style="font-size:15px; color:orange;">Review ID  : <?php echo $review_id; ?> </i>
                                                </td>
                                                
                                                
                                            </tr>
                                            <tr>
                                                <td colspan="2" style="border-top : #c4c5c6 solid 3px;">
                                                    <h4 align="center">Reported Details</h4>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <?php echo '<b>Name</b> : '.$fname ." ".$lname; ?>
                                                   
                                                </td>
                                                
                                                <td>
                                                     <b>Incident Date</b> : <?php 
                                                     if ($nodate == 1) 
                                                     {
                                                         echo "Date Unknown";
                                                     }
                                                     else
                                                     {
                                                        echo $date;
                                                     } 
                                                     ?> 
                                                    
                                                </td>
                                                
                                            </tr>
                                            <?php
                                            if ($inc_person =="In Patient") 
                                            {
                                                echo '<tr> 
                                                        <td> <b>Age<b> : '.$age.'</td>
                                                        
                                                        <td> <b>Gender</b> : '.$gender.'</td>
                                                        
                                                    </tr>';
                                                echo '<tr> 
                                                        <td> <b>Admit Reason</b> : '.$reason.'</td>
                                                        
                                                        <td> <b>Admit Date</b> : '.$admit_date.'</td>
                                                        
                                                    </tr>';

                                                echo '<tr>
                                                        
                                                        <td><b>Patient\'s Email</b> : '.$uemail.'</td>
                                                        <td></td>
                                                    </tr>
                                                        ';
                                                
                                            }
                                            
                                            if ($inc_person =="Out Patient") 
                                            {
                                                echo '<tr> 
                                                        <td> <b>Age</b> : '.$age.'</td>
                                                        
                                                        <td> <b>Gender</b> : '.$gender.'</td>
                                                        
                                                    </tr>';
                                                echo '<tr> 
                                                        <td> <b>Admit Reason</b> : '.$reason.'</td>
                                                        
                                                        <td> <b>Admit Date</b> : '.$admit_date.'</td>
                                                         
                                                    </tr>';

                                                echo '<tr>
                                                        <td><b>Patient\'s Email</b> : '.$uemail.'</td>
                                                        <td> </td>
                                                        
                                                    </tr>
                                                        ';
                                            }
                                            if ($inc_person=="Property/Process") 
                                            {
                                                echo '<tr>
                                                        <td><b>User\'s Email</b> : '.$uemail.'</td>
                                                        <td> </td>
                                                        
                                                    </tr>
                                                        ';
                                            }
                                            if ($inc_person=="Visitor") 
                                            {
                                                echo '<tr> 
                                                        <td> <b>Gender</b> : '.$gender.'</td>
                                                       
                                                        <td> <b>Reason</b> : '.$reason.'</td>
                                                        
                                                    </tr>';
                                                    
                                                echo '<tr>
                                                        <td> <b>Admit Date</b> : '.$admit_date.'</td>
                                                        <td><b>Visitor\'s Email</b> : '.$uemail.'</td>
                                                        
                                                        
                                                    </tr>
                                                        ';
                                                
                                            }
                                            if ($inc_person=="Staff Member") 
                                            {
                                                echo '<tr>
                                                        <td> <b>Designation</b> : '.$designation.'</td>
                                                        <td><b>Staff Member\'s Email</b> : '.$uemail.'</td>
                                                        
                                                        
                                                    </tr>
                                                        ';
                                            }
                                            ?>
                                          <tr> 
                                                <td colspan="2">
                                                    <p><b>Incident Description</b> : <br> <br><?php echo $inc_details ?></p>
                                                </td>
                                                
                                          </tr>
                                          <tr> 
                                                <td>
                                                    <b>Incident Unit/Department</b> : <?php echo $location."/". $department; ?>
                                                </td>
                                                <td>
                                                    <b>Occurred Location</b> : <?php echo $inc_location; ?>
                                                </td>
                                                
                                          </tr>
                                          <tr> 
                                                <td>
                                                    <b>Reported Location</b> : <?php echo $rpt_location; ?>
                                                </td>
                                                <td>
                                                    <b>Incident Type</b> : <?php echo $inc_type; ?>
                                                </td>
                                                
                                          </tr>
                                          <tr><td colspan="2"></td></tr>
                                          <tr><td colspan="2" style="border :none"></td></tr>
                                          <tr>
                                                <td colspan="2" style="border-top : #c4c5c6 solid 3px;">
                                                    <h4 align="center">Reviewed Details</h4>
                                                </td>
                                            </tr>
                                          <?php
                                          if ($inc_summery !="" || $inc_rating !="" || $inc_remark !="" || $rootcase !="") 
                                          {
                                              echo '<tr>
                                                        <td> <b>Incident Summery/Instructions</b> : '.$inc_summery.'</td>
                                                        <td><b>Incident Remark</b> : '.$inc_remark.'</td>
                                                        
                                                        
                                                    </tr>
                                                        ';
                                                        echo '<tr>
                                                        <td> <b>Incident Severity Rating</b> : '.$inc_rating.'</td>
                                                        <td><b>Root Cause</b> : '.$rootcase.'</td>
                                                        
                                                        
                                                    </tr>
                                                        ';
                                          }
                                          ?> 
                                    </table>
                                    <hr>
                                    <div id="accordion">
                                        <div class="card">
                                            <div class="card-header" id="headingOne">
                                                <h5 class="mb-0">
                                                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                        Review History 
                                                        </button>
                                                </h5>
                                            </div>
                                            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                            <div class="card-body">
                                    <!----------------------------------------------------->
                                    <div class="col-lg-12">
                                        <h3 align="center"> Review History</h3>
                                        <table class="table table-responsive">
                                            <tr>
                                                <td> <h5 align="center">Status</h5> </td>
                                                <td> <h5 align="center">Remark</h5> </td>
                                                <td> <h5 align="center">Date/Time</h5> </td>
                                                <td> <h5 align="center">Involved Person</h5> </td>
                                          </tr>
                                          <?php
                                          $stcl="";
                                            $logs = "SELECT * FROM inc_logs WHERE inc_id=$inc_id ORDER BY datestamp ASC";
                                                $getlogs = mysqli_query($connection, $logs);
                                                while ($row7 = mysqli_fetch_assoc($getlogs)) 
                                                {
                                                    if ($row7["curr_status"]=="Reported") 
                                                    {
                                                       $clb ="btn-info";
                                                       $stcl=""; 
                                                    }
                                                    if ($row7["curr_status"]=="Review") 
                                                    {
                                                       $clb ="btn-default";
                                                       $stcl ='style="background:#01c0c8!important; color: white"';
                                                    }
                                                    if ($row7["curr_status"]=="Hold") 
                                                    {
                                                       $clb ="btn-warning";
                                                       $stcl=""; 
                                                    }
                                                    if ($row7["curr_status"]=="Reject") 
                                                    {
                                                       $clb ="btn-danger"; 
                                                       $stcl="";
                                                    }
                                                    if ($row7["curr_status"]=="Completed") 
                                                    {
                                                       $clb ="btn-success";
                                                       $stcl ='style="background:#00c292!important; color: white"'; 
                                                    }
                                                    $loguser = $row7["user"];
                                                    if ($loguser !="Public User") 
                                                    {
                                                    
                                                    $glogus = "SELECT * FROM `admin` WHERE `empid`='$loguser'";
                                                    $getloguser = mysqli_query($connection, $glogus);
                                                        while ($logguser = mysqli_fetch_array($getloguser)) 
                                                            {
                                                                $logfname = $logguser['fname'];
                                                                $loglname = $logguser['lname'];
                                                            }
                                                            $invuser = $logfname." ".$loglname." (".$row7["user"].")";
                                                    }
                                                    else
                                                    {
                                                        $invuser = $row7["user"];
                                                    }
                                                    echo '
                                                        <tr>
                                                            <td><span class="label '.$clb.'" '.$stcl.'>'.$row7["curr_status"].'<span></td>
                                                            <td>'.$row7["remark"].'</td>
                                                            <td>'.$row7["datestamp"].'</td>
                                                            <td>'.$invuser.'</td>
                                                        </tr>
                                                    ';
                                                }

                                          ?>
                                        </table>
                                    </div>
                                    <!-----------------------------------------------------> 
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12" style="margin-top: 80px">
                                        <div class="col-lg-12" style="margin-top: 80px">
                                        <h3 align="center">Review Information</h3>
                                        <hr>
                                        <form action="" method="post">
                                            <div class="col-md-6">
                                                <label class="col-xs-3 control-label">Incident Summery/Instructions</label>
                                                <textarea style="height: 100px" class="form-control" name="summery"><?php echo $inc_summery; ?></textarea>
                                            </div>
                                            <div class="col-md-6">
                                                        <label class="col-xs-3 control-label">Remark</label>
                                                        <input type="text" class="form-control" name="remark" value="<?php echo $inc_remark; ?>">
                                            </div>
                                            <div class="col-md-6">
                                                        <label class="col-xs-3 control-label">Root Cause</label>
                                                        <input type="text" class="form-control" name="root" value="<?php echo $rootcase; ?>">
                                            </div>
                                            <div class="col-md-6">
                                                        <label class="col-xs-3 control-label">Incident Severity Rating</label>
                                                        <select class="form-control" name="israting">
                                                            <option value="">-- Select --</option>
                                                            <option value="ISR1" <?php if ($inc_rating=="ISR1") {echo "Selected";}?>>ISR1</option>
                                                            <option value="ISR2" <?php if ($inc_rating=="ISR2") {echo "Selected";}?>>ISR2</option>
                                                            <option value="ISR3" <?php if ($inc_rating=="ISR3") {echo "Selected";}?>>ISR3</option>
                                                            <option value="ISR4" <?php if ($inc_rating=="ISR4") {echo "Selected";}?>>ISR4</option>
                                                            <option value="Complaints" <?php if ($inc_rating=="Complaints") {echo "Selected";}?>>Complaints</option>
                                                            <option value="Near Miss" <?php if ($inc_rating=="Near Miss") {echo "Selected";}?>>Near Miss</option>
                                                            <option value="Other" <?php if ($inc_rating=="Other") {echo "Selected";}?>>Other</option>
                                                        </select>
                                                    </div>
                                            <div class="col-md-6">
                                                        <label class="col-xs-3 control-label">Incident Type</label>
                                                        <select class="form-control" name="ginc_type">
                                                            <option value="">-- Select --</option>
                                                            <option value="Client Insident" <?php if ($inc_type=="Client Insident") {echo "Selected";}?>>Client Insident </option>
                                                            <option value="Asset" <?php if ($inc_type=="Asset") {echo "Selected";}?>>Asset </option>
                                                            <option value="Assoult/Violation/Abouse" <?php if ($inc_type=="Assoult/Violation/Abouse") {echo "Selected";}?>>Assoult/Violation/Abouse</option>
                                                            <option value="Environmental" <?php if ($inc_type=="Environmental") {echo "Selected";}?>>Environmental</option>
                                                            <option value="Reputation" <?php if ($inc_type=="Reputation") {echo "Selected";}?>>Reputation</option>
                                                            <option value="Other" <?php if ($inc_type=="Other") {echo "Selected";}?>>Other </option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <br> <hr>
                                            <div class="col-md-4">

                                                        <label class="col-xs-3 control-label">Current Status</label>
                                                        <select class="form-control" name="stst">
                                                            <option value="">-- Select --</option>
                                                            <option value="Reported" <?php if ($curr_status=="Reported") {echo "Selected";}?>>Reported</option>
                                                            <option value="Review" <?php if ($curr_status=="Review") {echo "Selected";}?>>Review</option>
                                                            <option value="Hold" <?php if ($curr_status=="Hold") {echo "Selected";}?>>Hold</option>
                                                            <option value="Reject" <?php if ($curr_status=="Reject") {echo "Selected";}?>>Reject</option>
                                                            <option value="Completed" <?php if ($curr_status=="Completed") {echo "Selected";}?>>Completed</option>
                                                        </select>
                                            </div> 
                                            <div class="col-md-4">
                                                        <label class="col-xs-3 control-label">Current Status Remark</label>
                                                        <input type="text" class="form-control" name="stremark">
                                            </div>
                                            <div class="col-md-4">
                                            <label>Location Occurred</label>
                                                <select class="form-control" name="gslocation">
                                                        <option value="">-- Select Location--</option>
                                                        <?php
                                                        $getoclc = "SELECT * FROM `inc_locations`";
                                                        $get_oclc = mysqli_query($connection, $getoclc);
                                                        while ($lst_oclc = mysqli_fetch_array($get_oclc)) 
                                                        {
                                                             if ($inc_location==$lst_oclc["loc_name"]) 
                                                                {
                                                                    $d = "Selected";
                                                                }
                                                                else
                                                                {
                                                                    $d ="";
                                                                }
                                                            echo '<option value="'.$lst_oclc["loc_name"].'" '.$d.'>'.$lst_oclc["loc_name"].'</option>';
                                                            }
                                                        ?>
                                                </select>
                                                </div>
                                            <div class="col-md-4" style="margin-top: 25px">
                                                    <button type="submit" class="form-control btn btn-success" name="sub">Save</button>
                                                    </div> 
                                                    </div>    
                                        </form>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"> <?php echo date('Y'); ?> &copy; Hemas Hospitals. All Rights Reserved.. </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/tether.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <!--Style Switcher -->
    <script src="../plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('#se').click(function() {
    $('#adse').toggleClass('opendiv');
    });
    });
</script>
</body>
</html>
<?php
error_reporting(0);
require_once "../functions/db.php";
$message="";
//////////////////////////// Email for Admin ////////////////////////////
$glus = "SELECT * FROM `inc_email` WHERE `overdue`='1' AND `freq`='Daily' AND `role`='Admin'";
$getluser = mysqli_query($connection, $glus);
while ($ftuser = mysqli_fetch_array($getluser)) 
        {
            $lemploc = $ftuser['location'];
            $lemail = $ftuser['email'];
            $duedays = $ftuser['duedays'];
 
$sql = "SELECT * FROM inc_review WHERE DATE(datestamp) > (NOW() - INTERVAL '$duedays' DAY) AND `curr_status`='Reported' ORDER BY datestamp DESC";
$query = mysqli_query($connection, $sql);
//print_r($query);
if (mysqli_num_rows($query)==0) {
                                                    $message .= "<html>
                                                    <head>
                                                        <title>Overdue Incident Report | Daily</title>
                                                    </head>
                                                    <body>
                                                    <h1 align=\"center\"> Overdue Incident Report | Daily</h1>
                                                    <br>
                                                    <b> No Overdue Incidents.. </b>
                                                    </body>
                                                    </html>";
                                                }
                                                else{

                                                    $message .= '
                                                    <html>
                                                    <head>
                                                        <title>Overdue Incident Report | Daily</title>
                                                        <style Type="text/css">
                                                        table {
                                                            width:100%;
                                                            border-collapse: collapse;
                                                            border-bottom: 1px solid black;

                                                        }
                                                        th {
                                                            text-align: center;
                                                        }
                                                        th, td {
                                                            padding: 5px;
                                                        }
                                                        tr:hover {background-color: #f5f5f5;}
                                                        tr:nth-child(even) {background-color: #f2f2f2;}
                                                        </style>
                                                    </head>
                                                    <body>
                                                    <h1 align="center"> Overdue Incident Report | Daily</h1>
                                                    <div style="overflow-x:auto;">
                                                    <table border="1">
                                                    <thead bgcolor="gray">
                                                    <tr>
                                                        <th> Inc. ID</th>
                                                        <th> Inc. Date</th>
                                                        <th> Person Involved</th>
                                                        <th> Paitient/Emp ID</th>
                                                        <th> Name/Property</th>
                                                        <th> Status</th>
                                                        <th> Description</th>
                                                        <th> Unit/Department</th>
                                                        <th> Location Reported</th>
                                                        <th> Occurred location</th>
                                                        <th> Reported Date</th>
                                                        <th> User Involved</th>
                                                    </tr>
                                                </thead>
                                                
                                                <tbody>
                                                    ';
                                                

                                        while ($row2 = mysqli_fetch_array($query)) {
                                            // $id = $row["id"]
                                            if ($row2["date"]=="" && $row2["nodate"]==1) 
                                                    {
                                                       $getdate = "No Date";
                                                    }
                                                    else
                                                    {
                                                        $getdate = $row2["date"];
                                                    }
                                                                                                
                                    $message .= '
                                    <tr>
                                            <td>'.$row2["review_id"].'</td>
                                            <td>'.$getdate.'</td>
                                            <td class="max-texts">'.$row2["inc_person"].'</td>
                                            <td>'.$row2["paitient_emp_id"].'</td>
                                            <td>'.$row2["fname"]." ".$row2["lname"].'</td>
                                            <td><b>'.$row2["curr_status"].'</b></td>
                                            <td>'.$row2["inc_details"].'</td>
                                            <td>'.$row2["location"].' / '.$row2["department"].'</td>
                                            <td>'.$row2["rpt_location"].'</td>
                                            <td>'.$row2["inc_location"].'</td>
                                            <td>'.$row2["datestamp"].'</td>
                                            <td>'.$row2["user"].'</td>
                                         </tr>
                                         
                                    ';

                                    }

                                    $message .= "</table><div>
                                        </body>
</html>
                                    ";
                                }
// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: admin@example.com' . "\r\n";
$subject = "Incident Overdue Notification";

mail($lemail,$subject,$message,$headers);
$message="";
                }



//////////////////////////// End email for Admin ////////////////////////////

//////////////////////////// Email for QA ////////////////////////////
$message2 ="";
$inc_loc="";
$lus = "SELECT * FROM `inc_email` WHERE `overdue`='1' AND `freq`='Daily' AND `role`='QA'";
$etluser = mysqli_query($connection, $lus);
while ($tuser = mysqli_fetch_array($etluser)) 
        {
            $qlemploc = $tuser['location'];
            //$qlemail = $tuser['email'];
            $qduedays = $tuser['duedays'];
 
$sqlq = "SELECT * FROM inc_review WHERE DATE(datestamp) > (NOW() - INTERVAL '$qduedays' DAY) AND `curr_status`='Reported' AND `inc_location`='$qlemploc' ORDER BY datestamp DESC";
$queryq = mysqli_query($connection, $sqlq);


//print_r($query);
if (mysqli_num_rows($queryq)==0) {
                                                    $message2 .= "
                                                    <html>
                                                    <head>
                                                        <title>Overdue Incident Report | Daily</title>
                                                    </head>
                                                    <body>
                                                    <h1 align=\"center\"> Overdue Incident Report | Daily</h1>
                                                    <br>
                                                    <b> No Overdue Incidents.. </b>
                                                    </body>
                                                    </html>
                                                      ";
                                                }
                                                else{

                                                    $message2 .= '
                                                    <html>
                                                    <head>
                                                        <title>Overdue Incident Report | Daily</title>
                                                        <style Type="text/css">
                                                        table {
                                                            width:100%;
                                                            border-collapse: collapse;
                                                            border-bottom: 1px solid black;

                                                        }
                                                        th {
                                                            text-align: center;
                                                        }
                                                        th, td {
                                                            padding: 5px;
                                                        }
                                                        tr:hover {background-color: #f5f5f5;}
                                                        tr:nth-child(even) {background-color: #f2f2f2;}
                                                        </style>
                                                    </head>
                                                    <body>
                                                    <h1 align="center"> Overdue Incident Report | Daily</h1>
                                                    <div style="overflow-x:auto;">
                                                    <table border="1">
                                                    <thead bgcolor="gray">
                                                    <tr>
                                                        <th> Inc. ID</th>
                                                        <th> Inc. Date</th>
                                                        <th> Person Involved</th>
                                                        <th> Paitient/Emp ID</th>
                                                        <th> Name/Property</th>
                                                        <th> Status</th>
                                                        <th> Description</th>
                                                        <th> Unit/Department</th>
                                                        <th> Location Reported</th>
                                                        <th> Occurred location</th>
                                                        <th> Reported Date</th>
                                                        <th> User Involved</th>
                                                    </tr>
                                                </thead>
                                                
                                                <tbody>
                                                    ';
                                                

                                        while ($row = mysqli_fetch_array($queryq)) {
                                            // $id = $row["id"]
                                            if ($row["date"]=="" && $row2["nodate"]==1) 
                                                    {
                                                       $qgetdate = "No Date";
                                                    }
                                                    else
                                                    {
                                                        $qgetdate = $row2["date"];
                                                    }
                                               $inc_loc = $row["inc_location"];                                                 
                                    $message2 .= '
                                    <tr>
                                            <td>'.$row["review_id"].'</td>
                                            <td>'.$qgetdate.'</td>
                                            <td class="max-texts">'.$row["inc_person"].'</td>
                                            <td>'.$row["paitient_emp_id"].'</td>
                                            <td>'.$row["fname"]." ".$row["lname"].'</td>
                                            <td><b>'.$row["curr_status"].'</b></td>
                                            <td>'.$row["inc_details"].'</td>
                                            <td>'.$row["location"].' / '.$row["department"].'</td>
                                            <td>'.$row["rpt_location"].'</td>
                                            <td>'.$inc_loc.'</td>
                                            <td>'.$row["datestamp"].'</td>
                                            <td>'.$row["user"].'</td>
                                         </tr>
                                         
                                    ';

                                    }
                                    $message2 .= "</table> </div>
 </body>
</html>
                                    ";
                                }

// Always set content-type when sending HTML email
$headers2 = "MIME-Version: 1.0" . "\r\n";
$headers2 .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers2 .= 'From: admin@example.com' . "\r\n";
$subject2 = "Incident Overdue Notification";

$hplocus = "SELECT * FROM `inc_email` WHERE `role`='QA' AND location='$inc_loc'";
$hplog = mysqli_query($connection, $hplocus);
while ($gt=mysqli_fetch_array($hplog)) {
    $qlemail = $gt['email'];
   
mail($qlemail,$subject2,$message2,$headers2);
$message2="";
}
                            }

//////////////////////////// End Email for QA ////////////////////////////


?>